import json

my_dict = {}

with open(
    "population/gen_dictionary/kaikki.org-dictionary-English-words.json",
    "r",
    encoding="utf-8",
) as file:
    for line in file:
        data = json.loads(line)
        word = data["word"]
        part_of_speech = data["pos"]
        senses = data["senses"]
        for sense in senses:
            if "glosses" not in sense:
                continue
            definition = sense["glosses"][0]
            example = ""
            if "examples" in sense:
                example = sense["examples"][0]["text"]
                if word not in example:
                    example = ""

            if part_of_speech not in ["noun", "verb", "adj", "adv"]:
                part_of_speech = "other"
            # add to dictionary
            key = str((word, part_of_speech))
            if key not in my_dict:
                my_dict[key] = {definition: example}
            elif definition not in my_dict[key]:
                my_dict[key][definition] = example

with open("population/gen_dictionary/wikitionary.json", "w") as json_file:
    json.dump(my_dict, json_file, indent=2)
print("Complete")
