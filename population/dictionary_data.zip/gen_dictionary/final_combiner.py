import ast
import json

BAD_PUNCTUATION = ",; :."


def format_str(s):
    return s.rstrip(BAD_PUNCTUATION).capitalize()


print("Start")
with open(
    "population/gen_dictionary/wikitionary.json", "r", encoding="utf-8"
) as wiki_file:
    with open("population/gen_dictionary/english_wordnet.json", "r") as wordnet_file:
        wiki_dict = json.load(wiki_file)
        wordnet_dict = json.load(wordnet_file)

        my_dict = {}
        seen_words = set()

        for wordPos, defDict in wordnet_dict.items():
            # track seen words
            word = tuple(ast.literal_eval(wordPos))[0]
            seen_words.add(word)

            tempDefDict = {}
            for definition, example in defDict.items():
                tempDefDict[format_str(definition)] = format_str(example)
            my_dict[wordPos] = tempDefDict

        print("Compiled intermediate dictionary")

        for wordPos, defDict in wiki_dict.items():
            # skip words not in wordnet
            word = tuple(ast.literal_eval(wordPos))[0]
            if word not in seen_words:
                continue

            if wordPos in my_dict:
                # append the dictionary
                for definition, example in defDict.items():
                    if format_str(definition) not in my_dict[wordPos]:
                        my_dict[wordPos][format_str(definition)] = format_str(example)
                    elif my_dict[wordPos][format_str(definition)] == "":
                        my_dict[wordPos][format_str(definition)] = format_str(example)
            else:
                # make new entry
                tempDefDict = {}
                for definition, example in defDict.items():
                    tempDefDict[format_str(definition)] = format_str(example)
                my_dict[wordPos] = tempDefDict

        print("Compiled wiki dictionary")

# Manually add lethologica
word = "lethologica"
pos = "noun"
definition = "the inability to remember a particular word or name"
example = "He would grope for the words and he often apologized for his lethologica"

wordPos = str((word, pos))
lethologicaIn = wordPos in my_dict
print(f"Lethologica in? {lethologicaIn}")
my_dict[wordPos] = {format_str(definition): format_str(example)}

print(len(my_dict))

with open("population/gen_dictionary/complete_collection.json", "w") as json_file:
    json.dump(my_dict, json_file, indent=2)
print("Complete")
