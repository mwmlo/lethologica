import ast
import json

print("Start")
my_list = []
with open("population/gen_dictionary/complete_collection.json", "r") as file:
    loaded_dict = json.load(file)

    for wordPos, defDict in loaded_dict.items():
        word, part_of_speech = tuple(ast.literal_eval(wordPos))
        for definition, example in defDict.items():
            my_list.append(
                {
                    "word": word,
                    "part_of_speech": part_of_speech,
                    "definitions": definition,
                    "example": example,
                }
            )

print(len(my_list))
with open(
    "population/gen_dictionary/complete_collection_expanded.json", "w"
) as json_file:
    json.dump(my_list, json_file, indent=2)
print("Complete")
