import json
import re

my_dict = {}
with open("population/gen_dictionary/open_english_wordnet_2023.jsonl", "r") as file:
    for line in file:
        data = json.loads(line)
        members = data["@members"]
        definition = data["Definition"]
        lexfile = data["@lexfile"]
        part_of_speech, _ = lexfile.split(".")
        example = data["Example"]

        with_space = members.replace("_", " ")
        matches = re.findall(r"oewn-(\w+)-\S+", with_space)
        for word in matches:
            this_example = example if word in example else ""
            key = str((word, part_of_speech))
            if key not in my_dict:
                my_dict[key] = {definition: this_example}
            elif definition not in my_dict[key]:
                my_dict[key][definition] = this_example

with open("population/gen_dictionary/english_wordnet.json", "w") as json_file:
    json.dump(my_dict, json_file, indent=2)
